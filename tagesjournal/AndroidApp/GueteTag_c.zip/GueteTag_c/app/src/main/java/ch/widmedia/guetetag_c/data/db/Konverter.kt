package ch.widmedia.guetetag_c.data.db

import androidx.room.TypeConverter
import java.time.LocalDate

class Konverter {
    @TypeConverter
    fun fromLocalDate(datum: LocalDate?): String? = datum?.toString()

    @TypeConverter
    fun toLocalDate(wert: String?): LocalDate? = wert?.let { LocalDate.parse(it) }
}
