package ch.widmedia.guetetag_c.ui.entry

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.widmedia.guetetag_c.data.model.Eintrag
import ch.widmedia.guetetag_c.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EintragBearbeitenBildschirm(
    datum: LocalDate,
    vorhandenerEintrag: Eintrag?,
    onZurueck: () -> Unit,
    onSpeichern: (Eintrag) -> Unit,
    onLoeschen: (Eintrag) -> Unit
) {
    var bewertung by remember { mutableFloatStateOf(vorhandenerEintrag?.bewertung?.toFloat() ?: 5f) }
    var text by remember { mutableStateOf(vorhandenerEintrag?.text ?: "") }
    var loeschenDialog by remember { mutableStateOf(false) }

    val formatter = DateTimeFormatter.ofPattern("d. MMMM yyyy", Locale.GERMAN)
    val wochentag = datum.dayOfWeek
        .getDisplayName(TextStyle.FULL, Locale.GERMAN)
        .replaceFirstChar { it.uppercase() }

    val istNeu = vorhandenerEintrag == null

    if (loeschenDialog && vorhandenerEintrag != null) {
        AlertDialog(
            onDismissRequest = { loeschenDialog = false },
            title = {
                Text(
                    "Eintrag löschen",
                    style = MaterialTheme.typography.titleMedium,
                    color = TintenBlau
                )
            },
            text = {
                Text(
                    "Möchtest du diesen Eintrag wirklich unwiderruflich löschen?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TintenBlau.copy(alpha = 0.7f)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    loeschenDialog = false
                    onLoeschen(vorhandenerEintrag)
                }) {
                    Text("Löschen", color = BurgundRot)
                }
            },
            dismissButton = {
                TextButton(onClick = { loeschenDialog = false }) {
                    Text("Abbrechen", color = TintenBlau)
                }
            },
            containerColor = PergamentWeiss
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PergamentWeiss)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(TintenBlauSehr, TintenBlau)
                    )
                )
                .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
            IconButton(
                onClick = onZurueck,
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Zurück",
                    tint = PergamentWeiss
                )
            }

            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (istNeu) "Neuer Eintrag" else "Eintrag bearbeiten",
                    style = MaterialTheme.typography.titleMedium,
                    color = GoldAkzent
                )
                Text(
                    text = datum.format(formatter),
                    style = MaterialTheme.typography.bodySmall,
                    color = PergamentWeiss.copy(alpha = 0.7f)
                )
            }

            if (!istNeu) {
                IconButton(
                    onClick = { loeschenDialog = true },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Löschen",
                        tint = PergamentWeiss.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // ── Formular ──────────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
        ) {
            Spacer(Modifier.height(32.dp))

            // Datum-Anzeige
            Text(
                text = wochentag,
                style = MaterialTheme.typography.headlineSmall,
                color = TintenBlau
            )
            Text(
                text = datum.format(formatter),
                style = MaterialTheme.typography.bodyMedium,
                color = SeidenGrau
            )

            Spacer(Modifier.height(32.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(28.dp))

            // ── Bewertungs-Slider ─────────────────────────────────────────────
            Text(
                text = "Wie war dein Tag?",
                style = MaterialTheme.typography.titleSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(20.dp))

            // Große Bewertungs-Anzeige
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(bewertungsHintergrundFarbe(bewertung.roundToInt())),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = bewertung.roundToInt().toString(),
                            style = MaterialTheme.typography.displaySmall,
                            color = PergamentWeiss,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = bewertungsBeschreibung(bewertung.roundToInt()),
                        style = MaterialTheme.typography.bodySmall,
                        color = SeidenGrau,
                        letterSpacing = 0.8.sp
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // Slider
            Slider(
                value = bewertung,
                onValueChange = { bewertung = it },
                valueRange = 1f..10f,
                steps = 8,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("1", style = MaterialTheme.typography.labelSmall, color = SeidenGrau)
                Text("10", style = MaterialTheme.typography.labelSmall, color = SeidenGrau)
            }

            Spacer(Modifier.height(32.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(28.dp))

            // ── Text-Eingabe ──────────────────────────────────────────────────
            Text(
                text = "Notizen",
                style = MaterialTheme.typography.titleSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 160.dp),
                placeholder = {
                    Text(
                        "Was ist heute passiert? Was bewegt dich?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SeidenGrau.copy(alpha = 0.5f)
                    )
                },
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = TintenBlauSehr,
                    lineHeight = 26.sp
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldAkzent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    cursorColor = TintenBlau,
                    focusedContainerColor = PergamentWeiss,
                    unfocusedContainerColor = PergamentDunkel.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(Modifier.height(32.dp))

            // ── Speichern-Button ──────────────────────────────────────────────
            Button(
                onClick = {
                    val neuerEintrag = Eintrag(
                        id = vorhandenerEintrag?.id ?: 0,
                        datum = datum,
                        bewertung = bewertung.roundToInt(),
                        text = text.trim()
                    )
                    onSpeichern(neuerEintrag)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TintenBlau,
                    contentColor = PergamentWeiss
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Speichern",
                    style = MaterialTheme.typography.labelLarge
                )
            }

            // Abstand unten (10%)
            Spacer(Modifier.height(48.dp))
        }
    }
}

private fun bewertungsHintergrundFarbe(bewertung: Int) = when {
    bewertung >= 8 -> GoldAkzent
    bewertung >= 5 -> TintenBlauHell
    else -> BurgundRot
}

private fun bewertungsBeschreibung(bewertung: Int) = when (bewertung) {
    10 -> "AUSGEZEICHNET"
    9 -> "HERVORRAGEND"
    8 -> "SEHR GUT"
    7 -> "GUT"
    6 -> "BEFRIEDIGEND"
    5 -> "MITTELMÄSSIG"
    4 -> "WENIGER GUT"
    3 -> "SCHWIERIG"
    2 -> "SCHLECHT"
    else -> "SEHR SCHWIERIG"
}
