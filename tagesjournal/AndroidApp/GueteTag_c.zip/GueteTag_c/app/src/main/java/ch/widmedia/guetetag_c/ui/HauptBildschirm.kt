package ch.widmedia.guetetag_c.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.widmedia.guetetag_c.data.model.Eintrag
import ch.widmedia.guetetag_c.ui.calendar.KalenderAnsicht
import ch.widmedia.guetetag_c.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HauptBildschirm(
    eintraege: List<Eintrag>,
    datumMitEintrag: Set<LocalDate>,
    onDatumKlick: (LocalDate) -> Unit,
    onEintragKlick: (Eintrag) -> Unit,
    onExportKlick: () -> Unit,
    onImportKlick: () -> Unit,
    onLoeschen: (Eintrag) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuOffen by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PergamentWeiss)
    ) {
        // ── App Bar ───────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(listOf(TintenBlauSehr, TintenBlau))
                )
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Column {
                Text(
                    text = "GueteTag",
                    style = MaterialTheme.typography.headlineMedium,
                    color = GoldAkzent
                )
                Text(
                    text = "Dein persönliches Tagebuch",
                    style = MaterialTheme.typography.bodySmall,
                    color = PergamentWeiss.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
            }
            Box(modifier = Modifier.align(Alignment.CenterEnd)) {
                IconButton(onClick = { menuOffen = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menü", tint = PergamentWeiss)
                }
                DropdownMenu(
                    expanded = menuOffen,
                    onDismissRequest = { menuOffen = false },
                    modifier = Modifier.background(PergamentWeiss)
                ) {
                    DropdownMenuItem(
                        text = { Text("Exportieren", style = MaterialTheme.typography.bodyMedium, color = TintenBlau) },
                        onClick = { menuOffen = false; onExportKlick() }
                    )
                    DropdownMenuItem(
                        text = { Text("Importieren", style = MaterialTheme.typography.bodyMedium, color = TintenBlau) },
                        onClick = { menuOffen = false; onImportKlick() }
                    )
                }
            }
        }

        // ── Haupt-Inhalt: Kalender (40%) + Liste (50%) + Leerraum (10%) ───────
        // Wir verwenden weight() innerhalb dieser Column, um die Höhen aufzuteilen.

        // Kalender-Bereich: 40% des verbleibenden Platzes
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.40f)
                .background(PergamentDunkel)
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            KalenderAnsicht(
                datumMitEintrag = datumMitEintrag,
                onDatumKlick = onDatumKlick,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Goldene Trennlinie
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0x00C9A84C), GoldAkzent, Color(0x00C9A84C))
                    )
                )
        )

        // Eintrags-Liste: 50%
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.50f)
        ) {
            // Abschnitts-Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Einträge",
                    style = MaterialTheme.typography.titleMedium,
                    color = TintenBlau
                )
                Spacer(Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = "${eintraege.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SeidenGrau
                )
            }

            if (eintraege.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Noch keine Einträge vorhanden.\nTippe auf einen Tag im Kalender.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SeidenGrau,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(eintraege, key = { it.id }) { eintrag ->
                        EintragKarte(
                            eintrag = eintrag,
                            onClick = { onEintragKlick(eintrag) },
                            onLoeschen = { onLoeschen(eintrag) }
                        )
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }

        // 10% Leerraum unten
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.10f)
        )
    }
}

@Composable
fun EintragKarte(
    eintrag: Eintrag,
    onClick: () -> Unit,
    onLoeschen: () -> Unit,
    modifier: Modifier = Modifier
) {
    var loeschenDialog by remember { mutableStateOf(false) }
    val formatter = DateTimeFormatter.ofPattern("d. MMMM yyyy", Locale.GERMAN)

    if (loeschenDialog) {
        AlertDialog(
            onDismissRequest = { loeschenDialog = false },
            title = {
                Text("Eintrag löschen", style = MaterialTheme.typography.titleMedium, color = TintenBlau)
            },
            text = {
                Text(
                    "Möchtest du den Eintrag vom ${eintrag.datum.format(formatter)} wirklich löschen?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { loeschenDialog = false; onLoeschen() }) {
                    Text("Löschen", color = BurgundRot)
                }
            },
            dismissButton = {
                TextButton(onClick = { loeschenDialog = false }) {
                    Text("Abbrechen", color = TintenBlau)
                }
            },
            containerColor = PergamentWeiss
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PergamentWeiss),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Bewertungs-Badge
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(bewertungsFarbe(eintrag.bewertung).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${eintrag.bewertung}",
                    style = MaterialTheme.typography.titleLarge,
                    color = bewertungsFarbe(eintrag.bewertung),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                val wochentag = eintrag.datum.dayOfWeek
                    .getDisplayName(TextStyle.FULL, Locale.GERMAN)
                    .replaceFirstChar { it.uppercase() }
                Text(
                    text = "$wochentag, ${eintrag.datum.format(formatter)}",
                    style = MaterialTheme.typography.titleSmall,
                    color = TintenBlau
                )
                if (eintrag.text.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = eintrag.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = SeidenGrau,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(Modifier.width(8.dp))

            IconButton(
                onClick = { loeschenDialog = true },
                modifier = Modifier.size(32.dp)
            ) {
                Text("✕", color = SeidenGrau.copy(alpha = 0.5f), fontSize = 14.sp)
            }
        }
    }
}

private fun bewertungsFarbe(bewertung: Int) = when {
    bewertung >= 8 -> GoldAkzent
    bewertung >= 5 -> TintenBlauHell
    else -> BurgundRot
}
