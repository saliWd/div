package ch.widmedia.guetetag_c.data.db

import androidx.room.*
import ch.widmedia.guetetag_c.data.model.Eintrag
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface EintragDao {

    @Query("SELECT * FROM eintraege ORDER BY datum DESC")
    fun alleEintraege(): Flow<List<Eintrag>>

    @Query("SELECT * FROM eintraege WHERE datum = :datum LIMIT 1")
    suspend fun eintragFuerDatum(datum: LocalDate): Eintrag?

    @Query("SELECT datum FROM eintraege")
    fun alleDaten(): Flow<List<LocalDate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun einfuegen(eintrag: Eintrag): Long

    @Update
    suspend fun aktualisieren(eintrag: Eintrag)

    @Delete
    suspend fun loeschen(eintrag: Eintrag)

    @Query("SELECT * FROM eintraege")
    suspend fun alleEintraegeEinmalig(): List<Eintrag>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun alleEinfuegen(eintraege: List<Eintrag>)

    @Query("DELETE FROM eintraege")
    suspend fun alleLoeschen()
}
