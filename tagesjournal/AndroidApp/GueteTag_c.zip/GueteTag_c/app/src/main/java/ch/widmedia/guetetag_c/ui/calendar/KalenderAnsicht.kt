package ch.widmedia.guetetag_c.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.widmedia.guetetag_c.ui.theme.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun KalenderAnsicht(
    datumMitEintrag: Set<LocalDate>,
    onDatumKlick: (LocalDate) -> Unit,
    modifier: Modifier = Modifier
) {
    val heute = LocalDate.now()
    val vor14Tagen = heute.minusDays(13) // letzte 14 Tage inkl. heute

    // Finde den vorherigen Montag (oder heute wenn heute Montag)
    val startDerAnzeige = run {
        var d = vor14Tagen
        while (d.dayOfWeek != DayOfWeek.MONDAY) d = d.minusDays(1)
        d
    }

    // Finde den nächsten Sonntag nach heute (oder heute wenn Sonntag)
    val endeDerAnzeige = run {
        var d = heute
        while (d.dayOfWeek != DayOfWeek.SUNDAY) d = d.plusDays(1)
        d
    }

    // Alle Tage in der Anzeige
    val alleTage = mutableListOf<LocalDate?>()
    var current = startDerAnzeige
    while (!current.isAfter(endeDerAnzeige)) {
        alleTage.add(current)
        current = current.plusDays(1)
    }

    // In Wochen aufteilen
    val wochen = alleTage.chunked(7)

    Column(modifier = modifier) {
        // Monat/Jahr Titel
        val monate = buildString {
            var m = startDerAnzeige
            val gesehen = mutableSetOf<java.time.Month>()
            while (!m.isAfter(endeDerAnzeige)) {
                if (gesehen.add(m.month)) {
                    if (gesehen.size > 1) append(" · ")
                    append(
                        m.month.getDisplayName(TextStyle.FULL, Locale.GERMAN)
                            .replaceFirstChar { it.uppercase() }
                    )
                    if (m.year != heute.year) append(" ${m.year}")
                }
                m = m.plusMonths(1)
            }
        }

        Text(
            text = monate,
            style = MaterialTheme.typography.titleMedium,
            color = TintenBlau,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Wochentag-Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So").forEach { tag ->
                Text(
                    text = tag,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = SeidenGrau,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        Spacer(Modifier.height(8.dp))

        // Wochen-Zeilen
        wochen.forEach { woche ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                woche.forEach { datum ->
                    KalenderTag(
                        datum = datum,
                        hatEintrag = datum != null && datumMitEintrag.contains(datum),
                        istKlickbar = datum != null && !datum.isAfter(heute) && !datum.isBefore(vor14Tagen),
                        istHeute = datum == heute,
                        onKlick = { if (datum != null) onDatumKlick(datum) },
                        modifier = Modifier.weight(1f)
                    )
                }
                // Auffüllen falls Woche unvollständig
                repeat(7 - woche.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun KalenderTag(
    datum: LocalDate?,
    hatEintrag: Boolean,
    istKlickbar: Boolean,
    istHeute: Boolean,
    onKlick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (datum == null) return@Box

        val hintergrundFarbe = when {
            istHeute && hatEintrag -> GoldAkzent
            istHeute -> TintenBlau
            hatEintrag -> GoldAkzent.copy(alpha = 0.25f)
            else -> Color.Transparent
        }

        val textFarbe = when {
            istHeute -> PergamentWeiss
            hatEintrag -> TintenBlauSehr
            istKlickbar -> TintenBlau
            else -> SeidenGrau.copy(alpha = 0.5f)
        }

        val randFarbe = when {
            istHeute -> TintenBlau
            hatEintrag -> GoldAkzent.copy(alpha = 0.6f)
            else -> Color.Transparent
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(hintergrundFarbe)
                .border(
                    width = if (istHeute || hatEintrag) 1.5.dp else 0.dp,
                    color = randFarbe,
                    shape = CircleShape
                )
                .then(
                    if (istKlickbar) Modifier.clickable(onClick = onKlick)
                    else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = datum.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (istHeute || hatEintrag) FontWeight.Bold else FontWeight.Normal,
                color = textFarbe,
                textAlign = TextAlign.Center
            )
        }
    }
}
