package ch.widmedia.guetetag_c.data.repository

import android.content.Context
import android.net.Uri
import ch.widmedia.guetetag_c.data.model.Eintrag
import ch.widmedia.guetetag_c.security.SchluesselVerwaltung
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.security.SecureRandom

/**
 * Export-Format (binär):
 * [4 bytes magic] [16 bytes Salz] [12 bytes IV] [n bytes verschlüsselte JSON-Daten]
 */
object ExportImportManager {

    private val MAGIC = byteArrayOf(0x47, 0x54, 0x41, 0x47) // "GTAG"
    private const val SALZ_LAENGE = 16
    private const val IV_LAENGE = 12

    fun exportieren(eintraege: List<Eintrag>, passwort: String): ByteArray {
        val json = eintraegeZuJson(eintraege)
        val salz = ByteArray(SALZ_LAENGE).also { SecureRandom().nextBytes(it) }
        val schluessel = SchluesselVerwaltung.schluesselAusPasswort(passwort, salz)
        val (verschluesselt, iv) = SchluesselVerwaltung.verschluesseln(json.toByteArray(Charsets.UTF_8), schluessel)

        return ByteArrayOutputStream().apply {
            write(MAGIC)
            write(salz)
            write(iv)
            write(verschluesselt)
        }.toByteArray()
    }

    fun importieren(daten: ByteArray, passwort: String): List<Eintrag> {
        val buf = ByteBuffer.wrap(daten)

        val magic = ByteArray(4).also { buf.get(it) }
        require(magic.contentEquals(MAGIC)) { "Ungültiges Dateiformat" }

        val salz = ByteArray(SALZ_LAENGE).also { buf.get(it) }
        val iv = ByteArray(IV_LAENGE).also { buf.get(it) }
        val verschluesselt = ByteArray(buf.remaining()).also { buf.get(it) }

        val schluessel = SchluesselVerwaltung.schluesselAusPasswort(passwort, salz)
        val json = SchluesselVerwaltung.entschluesseln(verschluesselt, iv, schluessel)
            .toString(Charsets.UTF_8)

        return jsonZuEintraege(json)
    }

    fun speichernInDatei(context: Context, uri: Uri, daten: ByteArray) {
        context.contentResolver.openOutputStream(uri)?.use { stream ->
            stream.write(daten)
        } ?: throw IllegalStateException("Datei konnte nicht geöffnet werden")
    }

    fun ladenAusDatei(context: Context, uri: Uri): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.readBytes()
        } ?: throw IllegalStateException("Datei konnte nicht gelesen werden")
    }

    // --- Minimales JSON-Serialisierung ohne externe Bibliothek ---

    private fun eintraegeZuJson(eintraege: List<Eintrag>): String {
        val sb = StringBuilder("[")
        eintraege.forEachIndexed { idx, e ->
            if (idx > 0) sb.append(",")
            sb.append("""{"id":${e.id},"datum":"${e.datum}","bewertung":${e.bewertung},"text":${jsonString(e.text)}}""")
        }
        sb.append("]")
        return sb.toString()
    }

    private fun jsonString(s: String): String {
        val escaped = s
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
        return "\"$escaped\""
    }

    private fun jsonZuEintraege(json: String): List<Eintrag> {
        // Einfacher JSON-Parser für unser bekanntes Format
        val eintraege = mutableListOf<Eintrag>()
        val objektMuster = Regex("""\{[^}]+\}""")
        objektMuster.findAll(json).forEach { match ->
            try {
                val obj = match.value
                val id = felderExtrahieren(obj, "id")?.toLongOrNull() ?: 0L
                val datum = felderExtrahieren(obj, "datum")?.let {
                    java.time.LocalDate.parse(it)
                } ?: return@forEach
                val bewertung = felderExtrahieren(obj, "bewertung")?.toIntOrNull() ?: 5
                val text = felderExtrahierenString(obj, "text") ?: ""
                eintraege.add(Eintrag(id = 0, datum = datum, bewertung = bewertung, text = text))
            } catch (_: Exception) {}
        }
        return eintraege
    }

    private fun felderExtrahieren(json: String, feld: String): String? {
        val muster = Regex(""""$feld"\s*:\s*([^,}\s]+)""")
        return muster.find(json)?.groupValues?.get(1)?.trim('"')
    }

    private fun felderExtrahierenString(json: String, feld: String): String? {
        val muster = Regex(""""$feld"\s*:\s*"((?:[^"\\]|\\.)*)"""")
        return muster.find(json)?.groupValues?.get(1)
            ?.replace("\\\"", "\"")
            ?.replace("\\n", "\n")
            ?.replace("\\r", "\r")
            ?.replace("\\t", "\t")
            ?.replace("\\\\", "\\")
    }
}
