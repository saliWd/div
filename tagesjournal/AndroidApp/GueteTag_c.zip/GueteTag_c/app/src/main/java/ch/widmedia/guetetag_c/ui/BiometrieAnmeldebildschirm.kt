package ch.widmedia.guetetag_c.ui

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import ch.widmedia.guetetag_c.security.SchluesselVerwaltung
import ch.widmedia.guetetag_c.ui.theme.*

@Composable
fun BiometrieAnmeldebildschirm(
    onErfolgreich: () -> Unit
) {
    val context = LocalContext.current
    var fehlerText by remember { mutableStateOf<String?>(null) }
    var laden by remember { mutableStateOf(false) }

    val pulsAnimation = rememberInfiniteTransition(label = "puls")
    val pulsSkala by pulsAnimation.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulsSkala"
    )

    fun biometrieStarten() {
        fehlerText = null
        laden = true
        val activity = context as? FragmentActivity ?: run {
            fehlerText = "Interner Fehler: Keine Activity"
            laden = false
            return
        }
        val executor = ContextCompat.getMainExecutor(context)

        // Prüfen ob DB-Schlüssel bereits existiert
        val erstStart = !SchluesselVerwaltung.dbSchluesselGespeichert(context)

        val cipher = try {
            if (erstStart) {
                SchluesselVerwaltung.verschluesselungsCipher()
            } else {
                SchluesselVerwaltung.entschluesseltCipher(context)
            }
        } catch (e: Exception) {
            fehlerText = "Schlüsselfehler: ${e.message}"
            laden = false
            return
        }

        val cryptoObject = BiometricPrompt.CryptoObject(cipher)

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                laden = false
                try {
                    val authCipher = result.cryptoObject?.cipher!!
                    if (erstStart) {
                        // Ersten DB-Schlüssel generieren und verschlüsselt speichern
                        SchluesselVerwaltung.dbSchluesselErstellen(context, authCipher)
                    } else {
                        // DB-Schlüssel entschlüsseln (wird im ViewModel verwendet)
                        SchluesselVerwaltung.dbSchluesselEntschluesseln(context, authCipher)
                    }
                    onErfolgreich()
                } catch (e: Exception) {
                    fehlerText = "Schlüsselfehler nach Authentifizierung: ${e.message}"
                }
            }

            override fun onAuthenticationFailed() {
                laden = false
                fehlerText = "Authentifizierung fehlgeschlagen. Bitte erneut versuchen."
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                laden = false
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                ) {
                    fehlerText = "Fehler: $errString"
                }
            }
        }

        val prompt = BiometricPrompt(activity, executor, callback)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("GueteTag entsperren")
            .setSubtitle(if (erstStart) "Fingerabdruck für Erstzugang registrieren" else "Fingerabdruck oder Gesicht verwenden")
            .setNegativeButtonText("Abbrechen")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()

        prompt.authenticate(info, cryptoObject)
    }

    LaunchedEffect(Unit) {
        biometrieStarten()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(TintenBlauSehr, TintenBlau, TintenBlauHell)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 48.dp)
        ) {
            Text(
                text = "GueteTag",
                style = MaterialTheme.typography.displaySmall,
                color = GoldAkzent,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Dein persönliches Tagebuch",
                style = MaterialTheme.typography.bodyMedium,
                color = PergamentWeiss.copy(alpha = 0.6f),
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(64.dp))

            // Fingerabdruck-Symbol mit Puls-Animation
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(if (laden) 1f else pulsSkala)
                    .clip(CircleShape)
                    .background(TintenBlauHell.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(GoldAkzent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (laden) {
                        CircularProgressIndicator(
                            color = GoldAkzent,
                            modifier = Modifier.size(36.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(text = "☝", fontSize = 40.sp)
                    }
                }
            }

            Spacer(Modifier.height(40.dp))

            Text(
                text = if (laden) "Authentifizierung läuft…" else "Mit Fingerabdruck entsperren",
                style = MaterialTheme.typography.bodyMedium,
                color = PergamentWeiss.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )

            fehlerText?.let { fehler ->
                Spacer(Modifier.height(24.dp))
                Text(
                    text = fehler,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFFF8A80),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(32.dp))

            if (!laden) {
                OutlinedButton(
                    onClick = { biometrieStarten() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldAkzent),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldAkzent.copy(alpha = 0.6f))
                ) {
                    Text("Erneut versuchen", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // Dekorative Linie unten
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 56.dp)
                .width(60.dp)
                .height(1.dp)
                .background(GoldAkzent.copy(alpha = 0.4f))
        )
    }
}
