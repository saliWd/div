package ch.widmedia.guetetag_c.data.repository

import ch.widmedia.guetetag_c.data.db.EintragDao
import ch.widmedia.guetetag_c.data.model.Eintrag
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class EintragRepository(private val dao: EintragDao) {

    val alleEintraege: Flow<List<Eintrag>> = dao.alleEintraege()
    val alleDaten: Flow<List<LocalDate>> = dao.alleDaten()

    suspend fun eintragFuerDatum(datum: LocalDate): Eintrag? = dao.eintragFuerDatum(datum)

    suspend fun speichern(eintrag: Eintrag): Long = dao.einfuegen(eintrag)

    suspend fun aktualisieren(eintrag: Eintrag) = dao.aktualisieren(eintrag)

    suspend fun loeschen(eintrag: Eintrag) = dao.loeschen(eintrag)

    suspend fun alleExportieren(): List<Eintrag> = dao.alleEintraegeEinmalig()

    suspend fun alleImportieren(eintraege: List<Eintrag>) {
        dao.alleLoeschen()
        dao.alleEinfuegen(eintraege)
    }
}
