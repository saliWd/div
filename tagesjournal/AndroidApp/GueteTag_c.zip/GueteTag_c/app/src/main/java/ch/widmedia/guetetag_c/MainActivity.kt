package ch.widmedia.guetetag_c

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import ch.widmedia.guetetag_c.data.model.Eintrag
import ch.widmedia.guetetag_c.ui.*
import ch.widmedia.guetetag_c.ui.entry.EintragBearbeitenBildschirm
import ch.widmedia.guetetag_c.ui.export.ExportBildschirm
import ch.widmedia.guetetag_c.ui.export.ImportBildschirm
import ch.widmedia.guetetag_c.ui.theme.GueteTagTheme
import kotlinx.coroutines.launch
import java.time.LocalDate
import androidx.compose.material3.Scaffold

// Navigationszustände
sealed class Bildschirm {
    object Anmeldung : Bildschirm()
    object Haupt : Bildschirm()
    data class EintragBearbeiten(val datum: LocalDate, val vorhandenerEintrag: Eintrag?) : Bildschirm()
    object Export : Bildschirm()
    object Import : Bildschirm()
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            GueteTagTheme {
                GueteTagNavigator()
            }
        }
    }
}

@Composable
fun GueteTagNavigator() {
    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as GueteTagApp
    val viewModel: HauptViewModel = viewModel(
        factory = HauptViewModel.Fabrik(app.repository)
    )

    var aktuellerBildschirm by remember { mutableStateOf<Bildschirm>(Bildschirm.Anmeldung) }
    val snackbarHostState = remember { SnackbarHostState() }
    val koroutineScope = rememberCoroutineScope()

    val eintraege by viewModel.alleEintraege.collectAsState()
    val alleDaten by viewModel.alleDaten.collectAsState()
    val ereignis by viewModel.ereignis.collectAsState()

    // Ereignisse (Erfolg/Fehler) als Snackbar anzeigen
    LaunchedEffect(ereignis) {
        when (val e = ereignis) {
            is UiEreignis.Fehler -> {
                snackbarHostState.showSnackbar(e.nachricht)
                viewModel.ereignisZuruecksetzen()
            }
            is UiEreignis.Erfolg -> {
                snackbarHostState.showSnackbar(e.nachricht)
                viewModel.ereignisZuruecksetzen()
            }
            UiEreignis.Leer -> {}
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = ch.widmedia.guetetag_c.ui.theme.PergamentWeiss
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val bildschirm = aktuellerBildschirm) {
            is Bildschirm.Anmeldung -> {
                BiometrieAnmeldebildschirm(
                    onErfolgreich = { aktuellerBildschirm = Bildschirm.Haupt }
                )
            }

            is Bildschirm.Haupt -> {
                HauptBildschirm(
                    eintraege = eintraege,
                    datumMitEintrag = alleDaten.toHashSet(),
                    onDatumKlick = { datum ->
                        koroutineScope.launch {
                            val vorhandener = viewModel.eintragFuerDatum(datum)
                            aktuellerBildschirm = Bildschirm.EintragBearbeiten(datum, vorhandener)
                        }
                    },
                    onEintragKlick = { eintrag ->
                        aktuellerBildschirm = Bildschirm.EintragBearbeiten(eintrag.datum, eintrag)
                    },
                    onExportKlick = { aktuellerBildschirm = Bildschirm.Export },
                    onImportKlick = { aktuellerBildschirm = Bildschirm.Import },
                    onLoeschen = { eintrag -> viewModel.loeschen(eintrag) },
                    modifier = Modifier.fillMaxSize()
                )
            }

            is Bildschirm.EintragBearbeiten -> {
                EintragBearbeitenBildschirm(
                    datum = bildschirm.datum,
                    vorhandenerEintrag = bildschirm.vorhandenerEintrag,
                    onZurueck = { aktuellerBildschirm = Bildschirm.Haupt },
                    onSpeichern = { eintrag ->
                        viewModel.speichern(eintrag)
                        aktuellerBildschirm = Bildschirm.Haupt
                    },
                    onLoeschen = { eintrag ->
                        viewModel.loeschen(eintrag)
                        aktuellerBildschirm = Bildschirm.Haupt
                    }
                )
            }

            is Bildschirm.Export -> {
                ExportBildschirm(
                    viewModel = viewModel,
                    onZurueck = { aktuellerBildschirm = Bildschirm.Haupt }
                )
            }

            is Bildschirm.Import -> {
                ImportBildschirm(
                    viewModel = viewModel,
                    onZurueck = { aktuellerBildschirm = Bildschirm.Haupt }
                )
            }
        } // when
        } // Box
    } // Scaffold
}
