package ch.widmedia.guetetag_c.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import ch.widmedia.guetetag_c.data.model.Eintrag

/**
 * Haupt-Datenbankklasse. Die Datenbankdatei wird durch den Android-Geräteschutz
 * (Full-Disk Encryption / File-Based Encryption) geschützt und ist nur nach
 * biometrischer Authentifizierung über den App-Entsperrfluss zugänglich.
 */
@Database(
    entities = [Eintrag::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Konverter::class)
abstract class GueteTagDatenbank : RoomDatabase() {
    abstract fun eintragDao(): EintragDao

    companion object {
        @Volatile
        private var INSTANZ: GueteTagDatenbank? = null

        fun holen(context: Context): GueteTagDatenbank {
            return INSTANZ ?: synchronized(this) {
                val instanz = Room.databaseBuilder(
                    context.applicationContext,
                    GueteTagDatenbank::class.java,
                    "guetetag.db"
                ).build()
                INSTANZ = instanz
                instanz
            }
        }

        fun schliessen() {
            INSTANZ?.close()
            INSTANZ = null
        }
    }
}
