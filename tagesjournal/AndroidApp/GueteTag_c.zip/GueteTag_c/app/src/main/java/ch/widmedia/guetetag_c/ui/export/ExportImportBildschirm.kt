package ch.widmedia.guetetag_c.ui.export

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import ch.widmedia.guetetag_c.ui.HauptViewModel
import ch.widmedia.guetetag_c.ui.theme.*
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportBildschirm(
    viewModel: HauptViewModel,
    onZurueck: () -> Unit
) {
    val context = LocalContext.current
    val exportPasswort by viewModel.exportPasswort.collectAsState()
    var passwortSichtbar by remember { mutableStateOf(false) }
    var passwortBestaetigung by remember { mutableStateOf("") }
    var passwortBestaetigungSichtbar by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        uri?.let { viewModel.exportieren(context, it) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PergamentWeiss)
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(TintenBlauSehr, TintenBlau)
                    )
                )
                .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
            IconButton(
                onClick = onZurueck,
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Zurück",
                    tint = PergamentWeiss
                )
            }
            Text(
                text = "Daten exportieren",
                style = MaterialTheme.typography.titleMedium,
                color = GoldAkzent,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            Text(
                text = "Exportieren",
                style = MaterialTheme.typography.headlineSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Alle Einträge werden verschlüsselt in eine Datei exportiert. Das Passwort wird sicher auf diesem Gerät gespeichert.",
                style = MaterialTheme.typography.bodyMedium,
                color = SeidenGrau
            )

            Spacer(Modifier.height(32.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(28.dp))

            Text(
                text = "Export-Passwort",
                style = MaterialTheme.typography.titleSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = exportPasswort,
                onValueChange = viewModel::exportPasswortAendern,
                label = { Text("Passwort (mind. 4 Zeichen)", style = MaterialTheme.typography.bodySmall) },
                visualTransformation = if (passwortSichtbar) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { passwortSichtbar = !passwortSichtbar }) {
                        Text(
                            if (passwortSichtbar) "Verbergen" else "Anzeigen",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldAkzent
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldAkzent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    cursorColor = TintenBlau
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = passwortBestaetigung,
                onValueChange = { passwortBestaetigung = it },
                label = { Text("Passwort bestätigen", style = MaterialTheme.typography.bodySmall) },
                visualTransformation = if (passwortBestaetigungSichtbar) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { passwortBestaetigungSichtbar = !passwortBestaetigungSichtbar }) {
                        Text(
                            if (passwortBestaetigungSichtbar) "Verbergen" else "Anzeigen",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldAkzent
                        )
                    }
                },
                isError = passwortBestaetigung.isNotEmpty() && passwortBestaetigung != exportPasswort,
                supportingText = {
                    if (passwortBestaetigung.isNotEmpty() && passwortBestaetigung != exportPasswort) {
                        Text("Passwörter stimmen nicht überein", color = BurgundRot)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldAkzent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    cursorColor = TintenBlau
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(Modifier.height(32.dp))

            val kannExportieren = exportPasswort.length >= 4 &&
                    exportPasswort == passwortBestaetigung

            Button(
                onClick = {
                    val dateiname = "guetetag_export_${LocalDate.now()}.gtag"
                    exportLauncher.launch(dateiname)
                },
                enabled = kannExportieren,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TintenBlau,
                    contentColor = PergamentWeiss,
                    disabledContainerColor = TintenBlau.copy(alpha = 0.3f)
                )
            ) {
                Text("Datei speichern", style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(48.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportBildschirm(
    viewModel: HauptViewModel,
    onZurueck: () -> Unit
) {
    val context = LocalContext.current
    val importPasswort by viewModel.importPasswort.collectAsState()
    var passwortSichtbar by remember { mutableStateOf(false) }
    var ausgewaehlteUri by remember { mutableStateOf<android.net.Uri?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        ausgewaehlteUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PergamentWeiss)
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(TintenBlauSehr, TintenBlau)
                    )
                )
                .padding(horizontal = 8.dp, vertical = 12.dp)
        ) {
            IconButton(
                onClick = onZurueck,
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Zurück",
                    tint = PergamentWeiss
                )
            }
            Text(
                text = "Daten importieren",
                style = MaterialTheme.typography.titleMedium,
                color = GoldAkzent,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            Text(
                text = "Importieren",
                style = MaterialTheme.typography.headlineSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Achtung: Beim Import werden alle bestehenden Einträge überschrieben.",
                style = MaterialTheme.typography.bodyMedium,
                color = BurgundRot.copy(alpha = 0.8f)
            )

            Spacer(Modifier.height(28.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(24.dp))

            // Datei auswählen
            Text(
                text = "Exportdatei",
                style = MaterialTheme.typography.titleSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(12.dp))

            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = TintenBlau
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (ausgewaehlteUri != null) GoldAkzent else MaterialTheme.colorScheme.outline
                )
            ) {
                Text(
                    text = if (ausgewaehlteUri != null)
                        "✓  Datei ausgewählt"
                    else
                        "Datei auswählen",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (ausgewaehlteUri != null) GoldAkzent else TintenBlau
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = "Import-Passwort",
                style = MaterialTheme.typography.titleSmall,
                color = TintenBlau
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = importPasswort,
                onValueChange = viewModel::importPasswortAendern,
                label = { Text("Passwort der Exportdatei", style = MaterialTheme.typography.bodySmall) },
                visualTransformation = if (passwortSichtbar) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { passwortSichtbar = !passwortSichtbar }) {
                        Text(
                            if (passwortSichtbar) "Verbergen" else "Anzeigen",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldAkzent
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldAkzent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    cursorColor = TintenBlau
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(Modifier.height(32.dp))

            val kannImportieren = ausgewaehlteUri != null && importPasswort.isNotEmpty()

            Button(
                onClick = {
                    ausgewaehlteUri?.let { uri ->
                        viewModel.importieren(context, uri)
                        onZurueck()
                    }
                },
                enabled = kannImportieren,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TintenBlau,
                    contentColor = PergamentWeiss,
                    disabledContainerColor = TintenBlau.copy(alpha = 0.3f)
                )
            ) {
                Text("Jetzt importieren", style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(48.dp))
    }
}
