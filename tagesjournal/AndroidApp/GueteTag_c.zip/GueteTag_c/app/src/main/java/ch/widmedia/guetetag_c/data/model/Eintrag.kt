package ch.widmedia.guetetag_c.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(tableName = "eintraege")
data class Eintrag(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val datum: LocalDate,
    val bewertung: Int, // 1–10
    val text: String
)
