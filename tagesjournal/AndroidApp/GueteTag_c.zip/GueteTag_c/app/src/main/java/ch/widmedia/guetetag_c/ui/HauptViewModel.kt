package ch.widmedia.guetetag_c.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ch.widmedia.guetetag_c.data.model.Eintrag
import ch.widmedia.guetetag_c.data.repository.EintragRepository
import ch.widmedia.guetetag_c.data.repository.ExportImportManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

sealed class UiEreignis {
    data class Fehler(val nachricht: String) : UiEreignis()
    data class Erfolg(val nachricht: String) : UiEreignis()
    object Leer : UiEreignis()
}

class HauptViewModel(private val repository: EintragRepository) : ViewModel() {

    val alleEintraege: StateFlow<List<Eintrag>> = repository.alleEintraege
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val alleDaten: StateFlow<List<LocalDate>> = repository.alleDaten
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _ereignis = MutableStateFlow<UiEreignis>(UiEreignis.Leer)
    val ereignis: StateFlow<UiEreignis> = _ereignis.asStateFlow()

    private val _exportPasswort = MutableStateFlow("")
    val exportPasswort: StateFlow<String> = _exportPasswort.asStateFlow()

    private val _importPasswort = MutableStateFlow("")
    val importPasswort: StateFlow<String> = _importPasswort.asStateFlow()

    fun exportPasswortAendern(pw: String) { _exportPasswort.value = pw }
    fun importPasswortAendern(pw: String) { _importPasswort.value = pw }

    suspend fun eintragFuerDatum(datum: LocalDate): Eintrag? =
        repository.eintragFuerDatum(datum)

    fun speichern(eintrag: Eintrag) {
        viewModelScope.launch {
            try {
                repository.speichern(eintrag)
            } catch (e: Exception) {
                _ereignis.value = UiEreignis.Fehler("Speichern fehlgeschlagen: ${e.message}")
            }
        }
    }

    fun loeschen(eintrag: Eintrag) {
        viewModelScope.launch {
            try {
                repository.loeschen(eintrag)
                _ereignis.value = UiEreignis.Erfolg("Eintrag gelöscht")
            } catch (e: Exception) {
                _ereignis.value = UiEreignis.Fehler("Löschen fehlgeschlagen: ${e.message}")
            }
        }
    }

    fun exportieren(context: Context, uri: Uri) {
        val pw = _exportPasswort.value
        if (pw.length < 4) {
            _ereignis.value = UiEreignis.Fehler("Passwort muss mindestens 4 Zeichen haben")
            return
        }
        viewModelScope.launch {
            try {
                val eintraege = repository.alleExportieren()
                val daten = ExportImportManager.exportieren(eintraege, pw)
                ExportImportManager.speichernInDatei(context, uri, daten)
                _ereignis.value = UiEreignis.Erfolg("${eintraege.size} Einträge exportiert")
                _exportPasswort.value = ""
            } catch (e: Exception) {
                _ereignis.value = UiEreignis.Fehler("Export fehlgeschlagen: ${e.message}")
            }
        }
    }

    fun importieren(context: Context, uri: Uri) {
        val pw = _importPasswort.value
        if (pw.isEmpty()) {
            _ereignis.value = UiEreignis.Fehler("Bitte Passwort eingeben")
            return
        }
        viewModelScope.launch {
            try {
                val daten = ExportImportManager.ladenAusDatei(context, uri)
                val eintraege = ExportImportManager.importieren(daten, pw)
                repository.alleImportieren(eintraege)
                _ereignis.value = UiEreignis.Erfolg("${eintraege.size} Einträge importiert")
                _importPasswort.value = ""
            } catch (e: Exception) {
                _ereignis.value = UiEreignis.Fehler("Import fehlgeschlagen: Falsches Passwort oder beschädigte Datei")
            }
        }
    }

    fun ereignisZuruecksetzen() {
        _ereignis.value = UiEreignis.Leer
    }

    class Fabrik(private val repository: EintragRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return HauptViewModel(repository) as T
        }
    }
}
