package ch.widmedia.guetetag_c.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SchluesselVerwaltung {

    private const val KEYSTORE_ANBIETER = "AndroidKeyStore"
    private const val SCHLUESSEL_ALIAS = "GueteTagHauptSchluessel"
    private const val PREFS_NAME = "gt_sec_prefs"
    private const val PREF_DB_KEY_ENC = "db_key_enc"
    private const val PREF_DB_KEY_IV = "db_key_iv"
    private const val DB_KEY_LAENGE = 32
    private const val GCM_TAG_BITS = 128

    fun schluesselSicherstellen() {
        val ks = KeyStore.getInstance(KEYSTORE_ANBIETER).apply { load(null) }
        if (ks.containsAlias(SCHLUESSEL_ALIAS)) return

        val spec = KeyGenParameterSpec.Builder(
            SCHLUESSEL_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            .setInvalidatedByBiometricEnrollment(true)
            .build()

        KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_ANBIETER)
            .apply { init(spec) }
            .generateKey()
    }

    fun schluesselExistiert(): Boolean = runCatching {
        KeyStore.getInstance(KEYSTORE_ANBIETER).apply { load(null) }
            .containsAlias(SCHLUESSEL_ALIAS)
    }.getOrDefault(false)

    fun dbSchluesselGespeichert(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.contains(PREF_DB_KEY_ENC)
    }

    fun verschluesselungsCipher(): Cipher {
        val key = keystoreSchluessel()
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, key)
        }
    }

    fun entschluesseltCipher(context: Context): Cipher {
        val key = keystoreSchluessel()
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val iv = Base64.decode(prefs.getString(PREF_DB_KEY_IV, null)!!, Base64.DEFAULT)
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        }
    }

    fun dbSchluesselErstellen(context: Context, cipher: Cipher): ByteArray {
        val dbKey = java.security.SecureRandom().generateSeed(DB_KEY_LAENGE)
        val encrypted = cipher.doFinal(dbKey)
        val iv = cipher.iv
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(PREF_DB_KEY_ENC, Base64.encodeToString(encrypted, Base64.DEFAULT))
            .putString(PREF_DB_KEY_IV, Base64.encodeToString(iv, Base64.DEFAULT))
            .apply()
        return dbKey
    }

    fun dbSchluesselEntschluesseln(context: Context, cipher: Cipher): ByteArray {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encrypted = Base64.decode(prefs.getString(PREF_DB_KEY_ENC, null)!!, Base64.DEFAULT)
        return cipher.doFinal(encrypted)
    }

    fun schluesselAusPasswort(passwort: String, salz: ByteArray): SecretKey {
        val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = javax.crypto.spec.PBEKeySpec(passwort.toCharArray(), salz, 310_000, 256)
        val raw = factory.generateSecret(spec).encoded
        return javax.crypto.spec.SecretKeySpec(raw, "AES")
    }

    fun verschluesseln(daten: ByteArray, schluessel: SecretKey): Pair<ByteArray, ByteArray> {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, schluessel)
        }
        return cipher.doFinal(daten) to cipher.iv
    }

    fun entschluesseln(enc: ByteArray, iv: ByteArray, schluessel: SecretKey): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, schluessel, GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        return cipher.doFinal(enc)
    }

    private fun keystoreSchluessel(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_ANBIETER).apply { load(null) }
        return ks.getKey(SCHLUESSEL_ALIAS, null) as SecretKey
    }
}
