package ch.widmedia.guetetag_c

import android.app.Application
import android.util.Log
import ch.widmedia.guetetag_c.data.db.GueteTagDatenbank
import ch.widmedia.guetetag_c.data.repository.EintragRepository
import ch.widmedia.guetetag_c.security.SchluesselVerwaltung

class GueteTagApp : Application() {

    val datenbank by lazy { GueteTagDatenbank.holen(this) }
    val repository by lazy { EintragRepository(datenbank.eintragDao()) }

    override fun onCreate() {
        super.onCreate()
        try {
            SchluesselVerwaltung.schluesselSicherstellen()
        } catch (e: Exception) {
            // Fehler wird beim Entsperrvorgang behandelt
            Log.e("GueteTagApp", "Schlüssel konnte nicht erstellt werden", e)
        }
    }
}
