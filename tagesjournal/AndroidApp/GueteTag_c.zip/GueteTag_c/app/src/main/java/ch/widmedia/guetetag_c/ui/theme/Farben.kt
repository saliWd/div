package ch.widmedia.guetetag_c.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

// ── Edle Farbpalette ──────────────────────────────────────────────────────────
val TintenBlau     = Color(0xFF1A2744)
val TintenBlauHell = Color(0xFF2D3F6B)
val TintenBlauSehr = Color(0xFF0E1A32)
val PergamentWeiss = Color(0xFFFAF6EF)
val PergamentDunkel = Color(0xFFF0E9DB)
val GoldAkzent     = Color(0xFFC9A84C)
val BurgundRot     = Color(0xFF8B2252)
val SeidenGrau     = Color(0xFF8A8070)

val HellFarbschema = lightColorScheme(
    primary              = TintenBlau,
    onPrimary            = PergamentWeiss,
    primaryContainer     = TintenBlauHell,
    onPrimaryContainer   = PergamentWeiss,
    secondary            = GoldAkzent,
    onSecondary          = TintenBlauSehr,
    secondaryContainer   = Color(0xFFEDD898),
    onSecondaryContainer = TintenBlauSehr,
    tertiary             = BurgundRot,
    onTertiary           = PergamentWeiss,
    background           = PergamentWeiss,
    onBackground         = TintenBlauSehr,
    surface              = PergamentWeiss,
    onSurface            = TintenBlauSehr,
    surfaceVariant       = PergamentDunkel,
    onSurfaceVariant     = TintenBlau,
    outline              = Color(0xFFB8AA99),
    outlineVariant       = Color(0xFFD6CCBB),
    error                = BurgundRot,
    onError              = PergamentWeiss,
)

// ── Schriftarten ──────────────────────────────────────────────────────────────
val SerifSchrift = FontFamily.Serif
val SansSchrift  = FontFamily.SansSerif

@Composable
fun GueteTagTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HellFarbschema,
        typography  = GueteTagTypographie,
        content     = content
    )
}
