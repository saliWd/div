# GueteTag

Persönliches Tagebuch-App für Android (API 36+).

## Einrichtung in Android Studio

1. **Projekt öffnen**: Öffne diesen Ordner in Android Studio Panda (2025.3) via *File → Open*.
2. **Gradle-Wrapper**: Falls Android Studio nach dem `gradle-wrapper.jar` fragt, wähle  
   *"Use Gradle Wrapper"* – Android Studio lädt die Wrapper-Dateien automatisch herunter,  
   oder nutze *File → Project Structure → Project → Gradle Version*.  
   Alternativ: Terminal im Projekt-Root ausführen:
   ```
   gradle wrapper --gradle-version=8.14
   ```
3. **SDK-Pfad**: Stelle sicher, dass `local.properties` den korrekten SDK-Pfad enthält  
   (wird von Android Studio automatisch angelegt).
4. **Sync**: *File → Sync Project with Gradle Files*

## Sicherheitsarchitektur

- Die Datenbank ist durch Android FBE (File-Based Encryption) geschützt.
- Ein AES-256-GCM-Schlüssel im **Android Keystore** wird biometrisch gesichert.
- Export-Dateien werden mit **PBKDF2+AES-GCM** und einem Benutzerpasswort verschlüsselt.
- Keine Daten verlassen das Gerät ohne expliziten Export durch den Nutzer.
